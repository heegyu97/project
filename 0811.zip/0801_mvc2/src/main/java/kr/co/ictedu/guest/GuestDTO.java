package kr.co.ictedu.guest;

public class GuestDTO {

}//class
