package kr.co.ictedu.guest;

import org.springframework.stereotype.Service;

@Service
public class GuestService {

}//class
