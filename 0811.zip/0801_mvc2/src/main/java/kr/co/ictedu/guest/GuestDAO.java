package kr.co.ictedu.guest;

import org.springframework.stereotype.Repository;

@Repository
public class GuestDAO {

}//class
